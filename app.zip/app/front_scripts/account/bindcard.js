$(function() {
  $('#j-bind-sub').on('click', function(event) {
    event.preventDefault();
    $('#bind-form').hide();
    $('#bindcard-suc').fadeIn();
  });
});