### 模型收藏接口
> http://kp2.yuncai.com/lottery/trade/model-collect

- model_id=CK_19239
- star_level=5
- star_comment=%E6%98%9F%E7%BA%A7%E5%A4%87%E6%B3%A8
- model_comment=%E6%A8%A1%E5%9E%8B%E5%A4%87%E6%B3%A8

### 模型收藏或者修改获取模型数据接口
> http://kp2.yuncai.com/lottery/trade/get-model-collect-data
- model_id=CK_19239

### 模型取消收藏接口
> http://kp2.yuncai.com/lottery/trade/model-cancel-collect
- model_id=CK_19239
- user_id=12
- t=1420707470865

### 模型批量取消收藏接口
> http://kp2.yuncai.com/lottery/trade/model-batch-cancel-collect
- model_id=CE_19210,CK_19303,CK_19239
- rnd=0.20113700746594732

### 保存我的筛选接口
> http://kp2.yuncai.com/lottery/model/add-search

### 获取我保存的筛选条件接口
> http://kp2.yuncai.com/lottery/model/get-my-search

### 删除我保存的筛选条件接口
> http://kp2.yuncai.com/lottery/model/cancel-search
- search_id=251155

### 模型快速投注接口
> http://kp2.yuncai.com/lottery/trade/model-fast-buy
- project_issue=141030&
- model_id=CG_21799
- money=10

### 图表数据接口
> http://kp2.yuncai.com/lottery/trade/fetch-icon-data
- model_id=BD_55067
- t=1421051263982

### 模型投注记录
> http://kp2.yuncai.com/account/record/ajax
- type=3
- days=30
- page=1
- pageSize=10

### 查看模型详情接口
> http://kp2.yuncai.com/lottery/trade/view-detail
- order_no
